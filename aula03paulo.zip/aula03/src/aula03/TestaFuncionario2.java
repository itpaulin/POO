package aula03;

public class TestaFuncionario2 {

	public static void main(String[] args) {
		Funcionario funcionario1 = new Funcionario();
		Funcionario funcionario2 = new Funcionario();

		funcionario1.setNome("Fulano");
		funcionario1.setSalario(3000);

		funcionario2.setNome("Fulano");
		funcionario2.setSalario(3000);

		if (funcionario1 == funcionario2)
			System.out.println("IGUAIS");
		else
			System.out.println("DIFERENTES");
	}
}
