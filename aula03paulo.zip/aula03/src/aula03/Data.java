package aula03;

public class Data {
	private String dia;
	private String m�s;
	private String ano;

	public String getDataCompelta() {
		return this.dia + "/" + this.m�s + "/" + this.ano;
	}

	// GETADOS E SETADOS
	public String getDia() {
		return dia;
	}

	public void setDia(String dia) {
		this.dia = dia;
	}

	public String getM�s() {
		return m�s;
	}

	public void setM�s(String m�s) {
		this.m�s = m�s;
	}

	public String getAno() {
		return ano;
	}

	public void setAno(String ano) {
		this.ano = ano;
	}

	// METODOS
	public String mostraData() {
		return (this.dia + "/" + this.m�s + "/" + this.ano);

	}
}