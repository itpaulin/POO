package aula03;

public class Funcionario {
	private String nome, departamento;
	private double salario;
	private boolean ativo = true;
	private Data dataDeNascimento = new Data(); // get

	public boolean isAtivo() {
		return this.ativo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDepartamento() {
		return departamento;
	}

	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public Data getDataDeNascimento() {
		return dataDeNascimento;
	}

	public void setDataDeNascimento(Data dataDeNascimento) {
		this.dataDeNascimento = dataDeNascimento;
	}

	public void aumentarSalario(double percentual) {
		this.salario = this.salario + (this.salario * percentual / 100);
	}

	public void demiteFuncionario() {
		this.ativo = false;
	}

	public void mostra() {
		System.out.println("Nome: " + this.nome);
		System.out.println("Departamento" + this.departamento);
		System.out.println("Sal�rio R$" + this.salario);
		System.out.println((this.ativo) ? "Est� na empresa." : "N�o est� na empresa.");
		System.out.println("Data de nascimento: " + this.dataDeNascimento.getDataCompelta());

	}

}
