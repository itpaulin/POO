package aula03;

public class TestaEmpresa {
	public static void main(String[] args) {
		Empresa buss1 = new Empresa();
		buss1.setEmpregados(new Funcionario[5]);

		Funcionario func1 = new Funcionario();
		func1.setNome("Jo�o Paulo");
		func1.setDepartamento("financeiro");
		func1.setSalario(759.60);
		Data data1 = new Data();

		data1.setAno("2003");
		data1.setDia("23");
		data1.setM�s("03");

		func1.setDataDeNascimento(data1);

		func1.mostra();

		buss1.adiciona(func1);

	}
}
