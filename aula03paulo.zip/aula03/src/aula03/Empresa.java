package aula03;

public class Empresa {
	private String nome, cnpj;
	private Funcionario[] empregados;
	private int posicaoLivre;

	public void adiciona(Funcionario f) {
		this.empregados[this.posicaoLivre] = f;
		this.posicaoLivre++;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public Funcionario[] getEmpregados() {
		return empregados;
	}

	public void setEmpregados(Funcionario[] empregados) {
		this.empregados = empregados;
	}

}
