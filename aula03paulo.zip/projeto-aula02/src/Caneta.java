
public class Caneta {
		String cor;
		String marca;
		int tamanho;
		boolean tampa;

}


